

fun main(args: Array<String>) {
    val printer = Printer()
    val user = User(printer)
    user.printInfo()
    val diObj = DisplayInfo()
    val newUser = User(diObj)
    newUser.printInfo()
}

interface DoPrintJob {
    var message: String
    fun printInfo()
}

class Printer: DoPrintJob {
    override var message: String = "hey this a Printer"
    override fun printInfo() {
        println(message)
    }
}

class DisplayInfo: DoPrintJob {
    override var message: String = "hey this a DisplayInfo"
    override fun printInfo() {
        println(message)
    }
}


class User(val delegate: DoPrintJob): DoPrintJob by delegate {
    override var message: String = "hey this a Real Object"
    override fun printInfo() {
    println(message)
    }
}