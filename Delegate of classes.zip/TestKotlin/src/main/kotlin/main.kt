

fun main(args: Array<String>) {
    val printer = Printer()
    val user = User(printer)
    user.printInfo()
    val diObj = DisplayInfo()
    val newUser = User(diObj)
    newUser.printInfo()
}

interface DoPrintJob {
    fun printInfo()
}

class Printer: DoPrintJob {
    override fun printInfo() {
        println("I am a printer, doing print job")
    }
}

class DisplayInfo: DoPrintJob {
    override fun printInfo() {
        println("I am display info, just doing my job on behalf of real object!!!")
    }
}


class User(val delegate: DoPrintJob): DoPrintJob by delegate {
    override fun printInfo() {
        delegate.printInfo()
    }
}